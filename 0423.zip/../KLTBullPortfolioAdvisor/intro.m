function intro()
%INTRO Summary of this function goes here
%   Detailed explanation goes here
%Introduction
  fprintf('== Welcome ================================================\n\n AAAAAAAAA   AAAAAAAA     AA    AAAAAA     AAAAAA      AA \n AA          AA         AAAA        AA         AA    AAAA \n AA   AAAA   AAAAAAAA     AA    AAAAAA     AAAAAA      AA \n AA     AA   AA           AA        AA         AA      AA \n AAAAAAAAA   AAAAAAAA     AA    AAAAAA     AAAAAA      AA\n\n* P o r t f o l i o   A d v i s o r *\n\n + Introduction\n\n   Our group project is an application based on financial  \n   models that helps you determine the most profitable and \n   least risk stock portfolio.\n\n\n\n\n\nPress any key to continue...');
  pause;
  clc;

%About
  fprintf('== About Us ===============================================\n\n AAAAAAAAA   AAAAAAAA     AA    AAAAAA     AAAAAA      AA \n AA          AA         AAAA        AA         AA    AAAA \n AA   AAAA   AAAAAAAA     AA    AAAAAA     AAAAAA      AA \n AA     AA   AA           AA        AA         AA      AA \n AAAAAAAAA   AAAAAAAA     AA    AAAAAA     AAAAAA      AA\n\n* P o r t f o l i o   A d v i s o r *\n\n + Our Members\n\n   Name               SID\n   ---------------------------\n   SHI Beiying\n   XU Yaohai\n   ZOU Luoyi          54017313\n   JIN Luteng\n   SHI Zhongjie\n\nPress any key to continue...');
  pause;
  clc;

%Hello
  fprintf('== Hello ==================================================\n\n AAAAAAAAA   AAAAAAAA     AA    AAAAAA     AAAAAA      AA \n AA          AA         AAAA        AA         AA    AAAA \n AA   AAAA   AAAAAAAA     AA    AAAAAA     AAAAAA      AA \n AA     AA   AA           AA        AA         AA      AA \n AAAAAAAAA   AAAAAAAA     AA    AAAAAA     AAAAAA      AA\n\n* P o r t f o l i o   A d v i s o r *\n\n - Hello, World!\n\nPress any key to continue...');
  pause;
  clc;
  
end

